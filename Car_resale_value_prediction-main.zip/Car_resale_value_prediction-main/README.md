# Car_resale_value_prediction

> Car resale value prediction using machine learning and flask in python.
> Use Anaconda Software to run the project 
